function [y] = dpulse(T, t_max, fs, fc, B, td)
    ts = 1/fs;
    K = B/T;
    N = round(T/ts);
    t = (0:ts:(t_max-ts));
    y=cos(2*pi*(fc*(t - T/2 - td) + 0.5*K*(t - T/2 - td ).^2) ).* rect( (t - T/2 - td )/T );
end