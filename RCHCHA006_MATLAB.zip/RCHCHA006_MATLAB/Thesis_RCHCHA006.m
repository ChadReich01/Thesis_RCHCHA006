%% Ultrasonic Water Level Measurement - RCHCHA006

%% Clear variables and command window
close all;
clear all;
clc;
load('fir.mat');
%% Define constants and parameters
c = 343;                % [m/s]  ->speed of wave
 
% Radar parameters
fc = 40e3;              % [Hz]
fs = 205900;            % [Hz]  
ts = 1/fs;              % Sampling period
B = 4e3;                % Bandwidth (Hz) 
T = 0.025;              % Pulse length in [s]
NumPulses = 1;          % Number of pulses 
PRI = 0.05;               % Pulse Repetition Interval
K = B/T;                % Chirp rate
t  = (0:ts:(PRI-ts));   % Time vector (in seconds) 
 
% Target parameters 
R_target = [2 3];                     % Target range 
td = 2* R_target/c;                   % Time taken for signal to travel to target and back to the radar 

%% Generate the transmit signal
 
% Generate Transmit signal  
Tx_Signal = pulse(T, PRI, fs, fc, B);  % transmit signal with chirp pulse
% Generate the transmit pulse 
tp=(0:1:(round(T/ts)-1))*ts;
NumSamplesTxPulse = ceil(T/ts);   % number of samples of the transmit pulse 
Tx_p = Tx_Signal(1: NumSamplesTxPulse);     % transmit pulse only

%% USB VCP with STM32
%s = serial('COM4');
%s.BaudRate = 12e6;
%s.InputBufferSize = 1000000;
%fopen(s);
%fprintf(s,'2');
%data = fread(s, num_samples*2, 'uint8').';
%fclose(s);
%delete(s);
%% Reconstructing the data from the STM32
%data = reshape(data, [2, num_samples]).';
%data(:, 1) = bitshift(data(:, 1), 8);
%rx = data(:, 1) + data(:, 2);
%rx_pulse_time = (0:ts:PRI-ts);

%% Generate a simulated received signal - not transmitting as yet

% If the USB were to work, the Rx_Signal parameter in 'downmix' would be
% replaced by the rx variable above

% Generate the Received Signal
Rx_Signal = dpulse(T, PRI, fs, fc, B, td(1)) + dpulse(T, PRI, fs, fc, B, td(2));
%% downmixing
Tx_base = downmix(fc,Tx_p,tp,fir);
Rx_base = downmix(fc,Rx_Signal,t,fir);
%% match filtering
mf = matchfilter(Tx_base,Rx_base,fs,PRI,T);
RangeLineAxis_m = t*c/2;
figure;
plot(RangeLineAxis_m,(abs(mf)));
grid on;
title('Simulated return echo: tank 1/3 full', 'fontsize', 14);
xlabel('Range(m)', 'fontsize', 13); 
ylabel('Gain', 'fontsize', 13);