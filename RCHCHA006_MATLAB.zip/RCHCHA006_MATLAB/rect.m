function [y] = rect(t)
    y = abs(t) <= 0.5;
end

